import React from 'react'
import PropTypes from 'prop-types'

const Navbar = props => {
    return (
    <div>
         
    </div>
    )
          
}

Navbar.propTypes = {

}

export default Navbar
